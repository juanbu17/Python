

numbers= [1,2,3,4,5,6,7,8,9]

"""
for num in numbers:
    print(num)

for i in range(len(numbers)):
    print(numbers[i]) 

num = 0
while num < len(numbers):
    if num in numbers:
      print(num) 
    num+=1        

"""    
my_list = ["Negro Claro" , "Negro Oscuro" , "Negro Asabache"]


i = 0
while i < len(my_list):
    print(my_list[i]) 
    i+=1