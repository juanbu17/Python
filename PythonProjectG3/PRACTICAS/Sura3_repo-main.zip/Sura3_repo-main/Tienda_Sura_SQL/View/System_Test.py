from View.ViewSystem import ViewSystem

system_v = ViewSystem(None)

system_v.system_init()

