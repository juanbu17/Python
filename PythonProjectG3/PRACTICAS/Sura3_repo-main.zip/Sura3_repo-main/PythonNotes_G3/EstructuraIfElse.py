

aviable_appoinment = False


if aviable_appoinment == True:
    print("Cita Confirmada")
else:
    print("Cita no confirmada")    