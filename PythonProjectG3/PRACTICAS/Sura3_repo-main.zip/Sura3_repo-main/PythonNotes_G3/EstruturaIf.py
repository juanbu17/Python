

aviable_appoinment = False


if aviable_appoinment == True:
    print("Cita Confirmada")