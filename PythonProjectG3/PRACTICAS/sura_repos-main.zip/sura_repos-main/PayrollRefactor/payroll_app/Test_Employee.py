from payroll_app.Employee import Employee

employee =  Employee(None,None, None,None,None,None,None)


employee.employees = []

employee.create_user(employee.employees)
employee.create_user(employee.employees)

employee.list_employee_data(employee.employees)