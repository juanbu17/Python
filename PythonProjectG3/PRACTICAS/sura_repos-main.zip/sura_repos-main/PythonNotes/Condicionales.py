

"""
num = int(input("Ingrese un  número"))

print(type(num))

## Operadores comparación <, >, >= , <= , == , !=

num = 26 

num2 = 35

es_mayor = num > num2

#print(type(es_mayor))

print(es_mayor)

no_es_igual = num != num2

print(no_es_igual)

# Operador Logico and , or , not
"""
day = 18

class_number = 2

attendand = None

if day == 18 and class_number == 2:
    attendand = True
    print(attendand)

    
    

