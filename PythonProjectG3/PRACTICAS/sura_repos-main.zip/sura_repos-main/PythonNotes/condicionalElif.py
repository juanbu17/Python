

day = input("Ingrese dia").lower()





if day == "martes":
    print("Moviles 2")
elif day == "miercoles": 
    print("Nuevas Tecnologias") 
elif day == "jueves" :
    print("Moviles 1")  
else:
    print("Descanso")       