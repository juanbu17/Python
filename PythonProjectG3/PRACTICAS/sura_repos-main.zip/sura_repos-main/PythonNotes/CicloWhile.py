

num = 1

sum = 0
"""
while num <= 10:
    print(num)
    num+=1
"""
while num < 10:
    num+=1
    sum += num 
    print(sum)

    
   
