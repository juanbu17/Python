from MyPayrolllApp.Employee import Employee

employee = Employee(None, None,None, None, None, None,None)

employee.create_user()
employee.create_user()
employee.list_employees()

