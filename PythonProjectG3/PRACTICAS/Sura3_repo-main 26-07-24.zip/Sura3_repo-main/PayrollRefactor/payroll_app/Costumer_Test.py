from payroll_app.Costumer import Costumer

costumer = Costumer(None, None, None,None,None,None,None)


costumer.create_user()
costumer.create_user()
costumer.list_costumers()