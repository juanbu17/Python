

my_list = ["Negro Claro" , "Negro Oscuro" , "Negro Asabache"]


print(my_list[1])
my_list[0] = "Negro muy oscuro"

print(my_list[0])



my_list.append( "Negro Brillante Nebulosa")

print(my_list)


numbers= [1,2,3,4,5,6,7,8,9]

print(numbers[4:8])
print(numbers[4:])
print(numbers[1:-6])