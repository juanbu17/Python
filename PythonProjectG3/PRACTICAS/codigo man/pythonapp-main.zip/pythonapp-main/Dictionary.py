

my_dict = {"id": 70100100, "name": "Pepito", "tel": "3215241574", "active": "true"}


print(my_dict.get("name"))

print(my_dict.items())

print(my_dict.values())

print(my_dict.keys())

my_dict.update({"salary": 1500000})

print(my_dict)