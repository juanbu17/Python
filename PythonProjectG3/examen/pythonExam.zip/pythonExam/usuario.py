

class Usuario:
    def __init__(self, nombre, apellido, usuario, contrasena, salario_bruto):
        self.nombre = nombre
        self.apellido = apellido
        self.usuario = usuario
        self.contrasena = contrasena
        self.salario_bruto = salario_bruto

    def __str__(self):
        return f"{self.nombre} {self.apellido}"